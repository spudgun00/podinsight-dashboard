import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import localFont from "next/font/local"
import "./globals.css"
import { cn } from "@/lib/utils"

const fontSans = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
})

const fontMono = localFont({
  src: "../assets/fonts/SFMono-Regular.otf",
  variable: "--font-sf-mono",
})

export const metadata: Metadata = {
  title: "PodInsightHQ | Podcast Intelligence, Visualized",
  description:
    "Premium analytics dashboard for VCs and startup founders to track trending topics across 1,000+ hours of podcast content.",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className="dark">
      <body className={cn("font-sans antialiased", fontSans.variable, fontMono.variable)}>
        <div className="relative min-h-screen w-full bg-deep-black text-white">
          <div className="noise-overlay"></div>
          <div className="gradient-mesh"></div>
          <div className="pointer-events-none fixed inset-0 z-0 overflow-hidden">
            <div className="orb orb-1"></div>
            <div className="orb orb-2"></div>
            <div className="orb orb-3"></div>
          </div>
          <div className="relative z-10">{children}</div>
        </div>
      </body>
    </html>
  )
}
